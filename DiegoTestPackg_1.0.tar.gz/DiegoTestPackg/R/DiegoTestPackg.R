#'Cuadrado de un número
#'
#'Eleva cualquier nujmero al cuadrado
#'@param Valor numérico pasado a la función
#'@return El cuadrado del número pasado como parámetro
#'@export 
cuadrado<-function(x){
  return (x^2)
}